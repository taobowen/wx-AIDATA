// pages/useCenter/uploaddata/detail2/detail2.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  senddata:function(){
    wx.navigateTo({
      url: './senddata/senddata',
    })
  }

})