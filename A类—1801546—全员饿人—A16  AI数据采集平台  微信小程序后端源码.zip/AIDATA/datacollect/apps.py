from django.apps import AppConfig


class DatacollectConfig(AppConfig):
    name = 'datacollect'
